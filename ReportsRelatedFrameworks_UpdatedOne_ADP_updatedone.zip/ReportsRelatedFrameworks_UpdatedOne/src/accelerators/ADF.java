package accelerators;

public class ADF {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s;
		s=System.getProperty("user.dir")+"\\driver\\chromedriver.exe";
		System.out.println(s);
	}

}
