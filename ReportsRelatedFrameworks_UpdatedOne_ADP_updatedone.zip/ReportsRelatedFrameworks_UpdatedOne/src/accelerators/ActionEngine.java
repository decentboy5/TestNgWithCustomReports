
package accelerators;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import report.CReporter;

// TODO: Auto-generated Javadoc
/**
 * The Class ActionEngine.
 */
public class ActionEngine extends TestEngineWeb {
	
	/** The Constant LOG. */
	private static final Logger LOG = Logger.getLogger(ActionEngine.class);
	
	/** The msg click success. */
	private final String msgClickSuccess = "Successfully Clicked On ";
	
	/** The msg click failure. */
	private final String msgClickFailure = "Unable To Click On ";
	
	/** The msg type success. */
	private final String msgTypeSuccess = "Successfully Typed On ";
	
	/** launch Browser. */
	private final String browser_url = "Successfully launched the  ";
	
	/** The msg type failure. */
	private final String msgTypeFailure = "Unable To Type On ";
	
	/** The msg is element found success. */
	private final String msgIsElementFoundSuccess = "Successfully Found Element ";
	
	/** The msg is element found failure. */
	private final String msgIsElementFoundFailure = "Unable To Found Element ";
	
	/**
	 * Setdriver.
	 *
	 * @param driver the driver
	 * @param reporter the reporter
	 */
	/*public void setdriver(WebDriver driver,CReporter reporter)
	{
		this.Driver = driver;
		this.reporter = reporter;
		
	}*/
	
	/**
	 * Click.
	 *
	 * @param locator the locator
	 * @param locatorName the locator name
	 * @return true, if successful
	 * @throws Throwable the throwable
	 */
	public boolean click(By locator, String locatorName) throws Throwable
	{
		boolean status = false;
		try
		{
		WebDriverWait wait = new WebDriverWait(this.Driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(locator));
		this.Driver.findElement(locator).click();
		this.reporter.SuccessReport("Click" , this.msgClickSuccess + locatorName);
		status = true;
		}
		catch(Exception e)
		{
			status = false;
			LOG.info(e.getMessage());
			this.reporter.failureReport("Click", this.msgClickFailure + locatorName, this.Driver);
			
		}
		return status;
		
	}
	
	/**
	 * Checks if is element present.
	 *
	 * @param by the by
	 * @param locatorName the locator name
	 * @param expected the expected
	 * @return true, if is element present
	 * @throws Throwable the throwable
	 */
	public boolean isElementPresent(By by, String locatorName,boolean expected) throws Throwable
	{
		boolean status = false;
		try
		{
			WebDriverWait wait = new WebDriverWait(this.Driver, 60);
			wait.until(ExpectedConditions.elementToBeClickable(by));
			this.Driver.findElement(by);
			this.reporter.SuccessReport("isElementPresent" , this.msgIsElementFoundSuccess + locatorName);
			status = true;
		}
		catch(Exception e)
		{
			status = false;
			LOG.info(e.getMessage());
			if(expected == status)
			{
				this.reporter.SuccessReport("isElementPresent", locatorName + "is ElementPresent");
			}
			else
			{
				this.reporter.failureReport(locatorName + "is ElementPresent", this.msgIsElementFoundFailure + locatorName, this.Driver);
			}
		}
		return status;
	}
	
	/**
	 * Switch to frame.
	 *
	 * @param locator the locator
	 * @param locatorName the locator name
	 * @return true, if successful
	 * @throws Throwable the throwable
	 */
	public  boolean SwitchToFrame(By locator, String locatorName)
            throws Throwable{
     boolean flag = false;
    
     try {
  
     this.Driver.switchTo().defaultContent();
     WebDriverWait wait = new WebDriverWait(this.Driver, 60);
     wait.until(ExpectedConditions.elementToBeClickable(locator));
     //wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.name("tree")));
     this.Driver.switchTo().frame(this.Driver.findElement(locator));
     flag = true;
     return flag;
    
} catch (Exception e) {

     return false;
} finally {
     if (flag==false) {
            this.reporter.failureReport("Switch to Frame", "Switch to Frame failed" + locatorName);

     } else if (flag==true) {
            this.reporter.SuccessReport("Switch to Frame", "Switch to Frame done" + locatorName);
     }
}
    
    
}
	
	/**
	 * Type.
	 *
	 * @param locator the locator
	 * @param testdata the testdata
	 * @param locatorName the locator name
	 * @return true, if successful
	 * @throws Throwable the throwable
	 */
	public boolean launch() throws Throwable
	{
		boolean status = true;
		 Driver.get(Application_URL);
		 Driver.manage().window().maximize();
		 reporter.calculateSuiteStartTime();
		 this.reporter.SuccessReport("launch" , this.browser_url + Application_URL);
		 return status;
	}
	public boolean type(By locator, String testdata, String locatorName) throws Throwable
	{
		boolean status = false;
		try
		{
			WebDriverWait wait = new WebDriverWait(this.Driver, 5);
			wait.until(ExpectedConditions.elementToBeClickable(locator));
			this.Driver.findElement(locator).clear();
			this.Driver.findElement(locator).sendKeys(testdata);
			this.reporter.SuccessReport("type" , this.msgTypeSuccess + locatorName);
			status = true;
		}
		catch(Exception e)
		{
			status = false;
			e.printStackTrace();
			LOG.info(e.getMessage());
			this.reporter.failureReport("type", this.msgTypeFailure + locatorName, this.Driver);
		}
		
		return status;
	}
	
	/**
	 * Moves the mouse to the middle of the element. The element is scrolled
	 * into view and its location is calculated using getBoundingClientRect.
	 *
	 * @param locator            : Action to be performed on element (Get it from Object
	 *            repository)
	 * @param locatorName            : Meaningful name to the element (Ex:link,menus etc..)
	 * @return true, if successful
	 * @throws Throwable the throwable
	 */
	public boolean mouseover(By locator, String locatorName)
			throws Throwable {
		boolean flag = false;
		try {
			WebElement mo = this.Driver.findElement(locator);
			new Actions(this.Driver).moveToElement(mo).build().perform();
			flag = true;
			return true;
		} catch (Exception e) {

			return false;
		} finally {
			if (flag == false) {
				this.reporter.failureReport("MouseOver",
						"MouseOver action is not perform on" + locatorName,this.Driver);

			} else if (flag == true) {

				this.reporter.SuccessReport("MouseOver",
						"MouserOver Action is Done on" + locatorName);
			}
		}
	}
	
	/**
	 * Tab.
	 *
	 * @param locator the locator
	 * @param locatorName the locator name
	 * @return true, if successful
	 * @throws Throwable the throwable
	 */
	public boolean tab(By locator, String locatorName)
			throws Throwable {
		boolean flag = false;
		try {
			WebDriverWait wait = new WebDriverWait(this.Driver, 60);
			wait.until(ExpectedConditions.elementToBeClickable(locator));
			WebElement mo = this.Driver.findElement(locator);
			mo.sendKeys(Keys.TAB);
			flag = true;
			return true;
		} catch (Exception e) {

			return false;
		} finally {
			if (flag == false) {
				this.reporter.failureReport("Tab",
						"Tab action is not perform on " + locatorName,this.Driver);

			} else if (flag == true) {

				this.reporter.SuccessReport("Tab",
						"Tab Action is Done on " + locatorName);
			}
		}
	}

	/**
	 * JS click.
	 *
	 * @param locator the locator
	 * @param locatorName the locator name
	 * @return true, if successful
	 * @throws Throwable the throwable
	 */
	public  boolean JSClick(By locator, String locatorName)
			   throws Throwable {
			  
			  boolean flag = false;
			  try {if(!this.reporter.getBrowserContext().getBrowserName().equalsIgnoreCase("safari")){
			   WebDriverWait wait = new WebDriverWait(this.Driver, 60);
			   wait.until(ExpectedConditions.elementToBeClickable(locator));
			   WebElement element = this.Driver.findElement(locator);
			   JavascriptExecutor executor = (JavascriptExecutor) this.Driver;
			   executor.executeScript("arguments[0].click();", element);
			   // driver.executeAsyncScript("arguments[0].click();", element);

			   flag = true;
			  } else{
			   WebDriverWait wait = new WebDriverWait(this.Driver, 60);
			   wait.until(ExpectedConditions.elementToBeClickable(locator));
			   this.Driver.findElement(locator).click();
			   this.reporter.SuccessReport("Click" , this.msgClickSuccess + locatorName);
			   flag = true; 
			  }
			  }

			  catch (Exception e) {
			   


			  } finally {
			   if (flag == false) {
			    this.reporter.failureReport("Click",
			      "MouseOver action is not perform on" + locatorName);
			    return flag;
			   } else if (flag == true) {
			    this.reporter.SuccessReport("Click",
			      "MouserOver Action is Done on" + locatorName);
			    return flag;
			   }
			  }
			  return flag;  
			  
			 }
	/**
	 * Wait for element present.
	 *
	 * @param by the by
	 * @param locator the locator
	 * @param secs the secs
	 * @return true, if successful
	 * @throws Throwable the throwable
	 */
	public boolean waitForElementPresent(By by, String locator, int secs)
			throws Throwable {
		boolean status = false;
		
		try {
			
			WebDriverWait wait = new WebDriverWait(this.Driver, 60);
			wait.until(ExpectedConditions.elementToBeClickable(by));
			for (int i = 0; i < secs/2; i++)
			{
				List<WebElement> elements = this.Driver.findElements(by);
				if (elements.size()>0)
				{
					status = true;
					return status;

				} 
				else
				{
					this.Driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
				}
			}
	       
		
		} 
		catch (Exception e) {
			
			return status;
		} 
	
		return status;
		
	}
	
	/**
	 * Assert text on element.
	 *
	 * @param by            : Action to be performed on element (Get it from Object
	 *            repository)
	 * @param text            : expected text to assert on the element
	 * @param locatorName            : Meaningful name to the element (Ex:link text, label text
	 *            etc..)
	 * @return true, if successful
	 * @throws Throwable the throwable
	 */
	public boolean verifyText(By by, String text, String locatorName)
			throws Throwable {
		boolean flag = false;

		try {
			WebDriverWait wait = new WebDriverWait(this.Driver, 60);
			wait.until(ExpectedConditions.elementToBeClickable(by));
			String vtxt = getText(by, locatorName).trim();
			if(vtxt.equalsIgnoreCase(text.trim()))
			{
				flag = true;
			}
			else
			{
				flag = false;
			}
		} catch (Exception e) {
			return false;
		} finally {
			if (flag==false) {
				this.reporter.failureReport("VerifyText", text
						+ " is not present in the location" + locatorName);
				flag = false;
			} else if (flag==true) {
				this.reporter.SuccessReport("VerifyText", text
						+ " is present in the location " + locatorName);
				flag = true;
			}
		}
		return flag;

	}
	
	/**
	 * The innerText of this element.
	 *
	 * @param locator            : Action to be performed on element (Get it from Object
	 *            repository)
	 * @param locatorName            : Meaningful name to the element (Ex:label text, SignIn Link
	 *            etc..)
	 * @return the text
	 * @throws Throwable the throwable
	 * @return: String return text on element
	 */

	public String getText(By locator, String locatorName)
			throws Throwable {
		String text = "";
		boolean flag = false;
		try {
			WebDriverWait wait = new WebDriverWait(this.Driver, 60);
			wait.until(ExpectedConditions.elementToBeClickable(locator));
			if (isElementPresent(locator, locatorName,true)) {
				text = this.Driver.findElement(locator).getText();
				flag = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (flag ==false) {
				this.reporter.warningReport("GetText", "Unable to get Text from"
						+ locatorName);
			} else if (flag == true) {
				this.reporter.SuccessReport("GetText", "Able to get Text from"
						+ locatorName);
			}
		}
		return text;
	}
	
	/*
	 * public static int getResponseCode(String url) { try { return
	 * Request.Get(url).execute().returnResponse().getStatusLine()
	 * .getStatusCode(); } catch (Exception e) { throw new RuntimeException(e);
	 * } }
	 */
	/**
	 * This method verify check box is checked or not.
	 *
	 * @param locator            : Action to be performed on element (Get it from Object
	 *            repository)
	 * @param locatorName            : Meaningful name to the element (Ex:sign in Checkbox etc..)
	 * @return true, if is checked
	 * @throws Throwable the throwable
	 * @return: boolean value(True: if it is checked, False: if not checked)
	 */
	public boolean isChecked(By locator, String locatorName)
			throws Throwable {
		boolean bvalue = false;
		boolean flag = false;
		try {
			WebDriverWait wait = new WebDriverWait(this.Driver, 60);
			wait.until(ExpectedConditions.elementToBeClickable(locator));
			if (this.Driver.findElement(locator).isSelected()) {
				flag = true;
				bvalue = true;
			}
		} catch (NoSuchElementException e) {

			bvalue = false;
		} finally {
			if (flag==true) {
				this.reporter.SuccessReport("IsChecked", locatorName
						+ " is Selected");
				// throw new ElementNotFoundException("", "", "");

			} else if (flag==false) {
				this.reporter.failureReport("IsChecked", locatorName
						+ " is not Select");
			}
		}
		return bvalue;
	}

	/**
	 * Verify alert present or not.
	 *
	 * @return true, if successful
	 * @throws Throwable the throwable
	 * @return: Boolean (True: If alert preset, False: If no alert)
	 */
	public boolean AlertAccept() throws Throwable {
		boolean flag = false;
		try {

			// Check the presence of alert
			org.openqa.selenium.Alert alert = this.Driver.switchTo().alert();
			// if present consume the alert
			alert.accept();
			flag = true;
		} catch (NoAlertPresentException ex) {
			// Alert present; set the flag

			// Alert not present
			ex.printStackTrace();
		} finally {
			if (flag==false) {
				this.reporter.failureReport("Alert", "There was no alert to handle");
			} else if (flag==true) {
				this.reporter.SuccessReport("Alert",
						"The Alert is handled successfully");
			}
		}

		return flag;
	}
	
	/**
	 * Verify alert present or not for Safari.
	 *
	 * @return true, if successful
	 * @throws Throwable the throwable
	 * @return: Boolean (True: If alert preset, False: If no alert)
	 */
	public  boolean JSAcceptAlert()
			   throws Throwable {
			  
			  boolean flag = false;
			  try {
			   JavascriptExecutor executor = (JavascriptExecutor) this.Driver;
			   executor.executeScript("confirm = function(message){return true;};");  
			   executor.executeScript("alert = function(message){return true;};");  
			   executor.executeScript("prompt = function(message){return true;}");
			   flag = true;
			  
			  }

			  catch (Exception e) {
			   


			  } finally {
			   if (flag == false) {
			    this.reporter.failureReport("Accept Alert",
			      "Alert Accept performed " );
			    return flag;
			   } else if (flag == true) {
			    this.reporter.SuccessReport("Accept Alert",
			      "Alert Accept performed ");
			    return flag;
			   }
			  }
			  return flag;  
			  
			 }
	
	/**
	 * Verify alert present or not.
	 *
	 * @param filePath the file path
	 * @param locator the locator
	 * @param locatorName the locator name
	 * @return true, if successful
	 * @throws Throwable the throwable
	 * @return: Boolean (True: If alert preset, False: If no alert)
	 */
	public boolean uploadFile(String filePath, By locator, String locatorName) throws Throwable {
		boolean flag = false;
		try {
			WebDriverWait wait = new WebDriverWait(this.Driver, 60);
			wait.until(ExpectedConditions.elementToBeClickable(locator));
			click(locator, locatorName);
			Thread.sleep(5000);
			Actions KeyboardEvent = new Actions(this.Driver);
			KeyboardEvent.sendKeys(filePath);
			Thread.sleep(1000);
			KeyboardEvent.sendKeys(Keys.ENTER);	
			
		} catch (NoAlertPresentException ex) {
			// Alert present; set the flag

			// Alert not present
			ex.printStackTrace();
		} finally {
			if (flag==false) {
				this.reporter.failureReport("Alert", "There was no alert to handle");
			} else if (flag==true) {
				this.reporter.SuccessReport("Alert",
						"The Alert is handled successfully");
			}
		}

		return flag;
	}
	
	
	/**
	 * Select a value from Dropdown using send keys.
	 *
	 * @param locator            : Action to be performed on element (Get it from Object
	 *            repository)
	 * @param value            : Value wish type in dropdown list
	 * @param locatorName            : Meaningful name to the element (Ex:Year Dropdown, items
	 *            Listbox etc..)
	 * @return true, if successful
	 * @throws Throwable the throwable
	 */
	public boolean selectBySendkeys(By locator, String value,
			String locatorName) throws Throwable {

		boolean flag = false;
		try {
			WebDriverWait wait = new WebDriverWait(this.Driver, 60);
			wait.until(ExpectedConditions.elementToBeClickable(locator));
			if(this.reporter.getBrowserContext().getBrowserName().equalsIgnoreCase("ie") || this.reporter.getBrowserContext().getBrowserName().equalsIgnoreCase("safari")){
				this.Driver.findElement(locator).click();
				Select drp = new Select(this.Driver.findElement(locator));
				drp.selectByVisibleText(value);
			}
			else{
				this.Driver.findElement(locator).sendKeys(value);	
			}
			flag = true;
			return true;
		} catch (Exception e) {

			return false;
		} finally {
			if (flag==false) {
				this.reporter.failureReport("Select", value
						+ "is Not Select from the DropDown " + locatorName);
				// throw new ElementNotFoundException("", "", "");

			} else if (flag==true) {
				this.reporter.SuccessReport("Select", value
						+ " is Selected from the DropDown " + locatorName);
			}
		}
	}

	/**
	 * select value from DropDown by using selectByIndex.
	 *
	 * @param locator            : Action to be performed on element (Get it from Object
	 *            repository)
	 * @param index            : Index of value wish to select from dropdown list.
	 * @param locatorName            : Meaningful name to the element (Ex:Year Dropdown, items
	 *            Listbox etc..)
	 * @return true, if successful
	 * @throws Throwable the throwable
	 */
	public boolean selectByIndex(By locator, int index,
			String locatorName) throws Throwable {
		boolean flag = false;
		try {
			WebDriverWait wait = new WebDriverWait(this.Driver, 60);
			wait.until(ExpectedConditions.elementToBeClickable(locator));
			Select s = new Select(this.Driver.findElement(locator));
			s.selectByIndex(index);
			flag = true;
			return true;
		} catch (Exception e) {

			return false;
		} finally {
			if (flag==false) {
				this.reporter.failureReport("Select", "Option at index " + index
						+ " is Not Select from the DropDown" + locatorName);

			} else if (flag==true) {
				this.reporter.SuccessReport("Select", "Option at index " + index
						+ "is Selected from the DropDown" + locatorName);
			}
		}
	}
	
	
	/**
	 * Switch to.
	 *
	 * @param url the url
	 * @return true, if successful
	 * @throws Throwable the throwable
	 */
	public boolean switchTo(String url)throws Throwable {
		boolean flag = false;
		try {
			Driver.navigate().to(url);
			flag = true;
		} catch (NoAlertPresentException ex) {
			// Alert present; set the flag

			// Alert not present
			ex.printStackTrace();
		} finally {
			if (flag==false) {
				this.reporter.failureReport("Alert", "There was no alert to handle");
			} else if (flag==true) {
				this.reporter.SuccessReport("Alert",
						"The Alert is handled successfully");
			}
		}

		return flag;
		
	}
	public boolean enter(By locator, String locatorName)
			throws Throwable {
		boolean flag = false;
		try {
			WebDriverWait wait = new WebDriverWait(this.Driver, 60);
			wait.until(ExpectedConditions.elementToBeClickable(locator));
			WebElement mo = this.Driver.findElement(locator);
			mo.sendKeys(Keys.ENTER);
			Thread.sleep(2000);
			flag = true;
			return true;
		} catch (Exception e) {

			return false;
		} finally {
			if (flag == false) {
				this.reporter.failureReport("Enter",
						"Tab action is not perform on " + locatorName,this.Driver);

			} else if (flag == true) {

				this.reporter.SuccessReport("Enetr",
						"Tab Action is Done on " + locatorName);
			}
		}
	}

	
	public String strwithtimestamp(String str) {
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		Date date = new Date();
		String strDateStamp = dateFormat.format(date);
		strDateStamp = ((strDateStamp.replace(" ", "_")).replace("/", "_"))
				.replace(":", "_");
		
		return str+strDateStamp;
	}
	
	public void FilterCheck(By Filter_Locator, By Grid_Locator, String Value)
            throws Throwable {
     type(Filter_Locator, Value, "Filter");
     if(this.reporter.getBrowserContext().getBrowserName().equalsIgnoreCase("safari")){
         enter(Filter_Locator, "presss the Enter key");
         Thread.sleep(5000);
         }else{
         	tab(Filter_Locator, "presss the Enter key");
         	 Thread.sleep(5000);
         }
     String Str_optionset_name = getText(Grid_Locator, "Name");
     if (Value.equals(Str_optionset_name)) {
            boolean validationPoint = isElementPresent(Grid_Locator,
                         "Optionset name", true);
            if (validationPoint) {
                  this.reporter.SuccessReport(
                                "User is able to verify Optionset name from grid",
                                "User is able to verify Optionset name from grid");
            } else {
                  this.reporter.failureReport(
                                "User is not able to verify Optionset name from grid",
                                "User is not able to verify Optionset name from grid",
                                this.Driver);
            }
     	}
	}
}