package accelerators;



import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;


import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;


import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

import report.CReporter;
import report.ReporterConstants;


public class TestEngineWeb {
	
	boolean proceedExecution = false;
	/** The Constant LOG. */
	private static final Logger LOG = Logger.getLogger(TestEngineWeb.class);

	
	/** The Driver. */
	public WebDriver Driver = null;
	
	/** The reporter. */
	public CReporter reporter = null;
	
	/** The browser. */
	/*cloud platform*/
	public String browser = null;
    
    /** The version. */
    public String version = null;
    
    /** The platform. */
    public String platform = null;
    
    /** The environment. */
    public String environment = null;
    
    /** The local base url. */
    public String localBaseUrl = null;
    
    /** The cloud base url. */
    public String cloudBaseUrl = null;
    
    /** The user name. */
    public String userName = null;
    
    /** The access key. */
    public String accessKey = null;
    
    /** The cloud implicit wait. */
    public String cloudImplicitWait = null;
    
    /** The cloud page load time out. */
    public String cloudPageLoadTimeOut = null;
    
    /** The update jira. */
    public String updateJira = null;
    
    /** The build number. */
    public String buildNumber = "";
    
    /** The job name. */
    public String jobName = "";
    
    /** The executed from. */
    public String executedFrom = null;       
    
    /** The url . */
    public String urlRem = "DEMO App";
	

    /**Test Environment URL **/
    public String Application_URL =null;
    public String urlOpcs = null;


	@BeforeClass
	//@Parameters({"browser","browserVersion","environment","platformName"})
	//public void Helloooo(String browser, String browserVersion,String environment,String platformName) throws IOException, InterruptedException
	public void Helloooo() throws IOException, InterruptedException
	{
		String platformName="flotform";	
		String environment="local";
		String browser="Firefox";
		String browserVersion="34";
			if(environment.equalsIgnoreCase("local"))
			{
				setWebDriverForLocal(browser);
			}
			
			reporter = CReporter.getCReporter(browser, browserVersion , environment, true);
	      
			Application_URL = ReporterConstants.MYURL;
			
	       
			
			
	}
		

	
	/**
	 * After test. - Close Driver & Reporter instance
	 *
	 * @throws Exception the exception
	 */
	@AfterClass
	
	public void afterTest() throws Exception
	{
			//Driver.close();
			Driver.quit();
			reporter.calculateSuiteExecutionTime();
		    if(urlRem.equalsIgnoreCase("DEMO App")){
	        	reporter.createHtmlSummaryReport(this.urlOpcs,true);
	        	}

			reporter.closeSummaryReport();
	}
	
	
	/**
	 * Before method.
	 *
	 * @param method the method
	 */
	@BeforeMethod
	
	public void beforeMethod(Method method)
	{
		
		
		//get browser info		
		//reporter = CReporter.getCReporter(deviceName, platformName, platformVersion, true);	
		reporter.initTestCase(this.getClass().getName().substring(0,this.getClass().getName().lastIndexOf(".")), method.getName(), null, false);
	
	}
	
	/**
	 * After method.
	 *
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@AfterMethod
	
	public void afterMethod() throws IOException
	{
		//get browser info				
		reporter.calculateTestCaseExecutionTime();		
		reporter.closeDetailedReport();		
		reporter.updateTestCaseStatus();
	}
	
	public void setWebdriverForGrid(String browser,String nodeUrl) throws MalformedURLException{
		DesiredCapabilities caps = new DesiredCapabilities();
		if(browser.equalsIgnoreCase("IE")){
			caps = DesiredCapabilities.internetExplorer();
			//caps.setPlatform(Platform.ANY);
		}
		else if(browser.equalsIgnoreCase("Firefox")){
			caps = DesiredCapabilities.firefox();
			//caps.setBrowserName("firefox");
			//caps.setVersion("33.0");
			caps.setPlatform(Platform.WINDOWS);
		}
		else if(browser.equalsIgnoreCase("chrome")){
			caps = DesiredCapabilities.chrome();
			//caps.setPlatform(Platform.ANY);
		}
		else {
			caps = DesiredCapabilities.safari();
			//caps.setPlatform(Platform.ANY);
		}
		 //String Node = "http://172.16.14.172:5555/wd/hub";
		//URL commandExecutorUri = new URL("http://ondemand.saucelabs.com/wd/hub");
		this.Driver = new RemoteWebDriver(new URL(nodeUrl), caps);
	}
	
	/*
	  Browser Initialization
	 */
	private void setWebDriverForLocal(String browser) throws IOException, InterruptedException
	{
   		    	
	
		if(browser.equalsIgnoreCase("Firefox"))
		{
			Driver=new FirefoxDriver();
			/*String s;
			s=System.getProperty("user.dir")+"\\driver\\chromedriver.exe";
			System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"\\driver\\chromedriver.exe");
			
			DesiredCapabilities capabilities = DesiredCapabilities.chrome();
			ChromeOptions options = new ChromeOptions();
			options.addArguments("test-type");
			options.addArguments("--start-maximized");
			options.addArguments("--ignore-certificate-errors");
			capabilities.setJavascriptEnabled(true);
			capabilities.setCapability(ChromeOptions.CAPABILITY, options);
			Driver=new ChromeDriver(capabilities);*/
			//Driver = new FirefoxDriver();
		}
		

	}
	
	/**
	 * Sets the remote web driver for cloud sauce labs.
	 *
	 * @throws MalformedURLException the malformed url exception
	 */
	private void setRemoteWebDriverForCloudSauceLabs() throws MalformedURLException
    {
        DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
        desiredCapabilities.setCapability(CapabilityType.BROWSER_NAME, this.browser);
        desiredCapabilities.setCapability(CapabilityType.VERSION, this.version);
        desiredCapabilities.setCapability(CapabilityType.PLATFORM, this.platform);
        desiredCapabilities.setCapability("username", this.userName);
        desiredCapabilities.setCapability("accessKey", this.accessKey);
        desiredCapabilities.setCapability("name", this.executedFrom + " - " + this.jobName + " - " + this.buildNumber + " - ");
        URL commandExecutorUri = new URL("http://ondemand.saucelabs.com/wd/hub");
        this.Driver = new RemoteWebDriver(commandExecutorUri, desiredCapabilities);
    }
	
	/**
	 * Update configuration for cloud sauce labs jenkins.
	 */
	private void updateConfigurationForCloudSauceLabsJenkins()
    {
        this.browser = System.getenv("SELENIUM_BROWSER");
        this.version = System.getenv("SELENIUM_VERSION");
        this.platform = System.getenv("SELENIUM_PLATFORM");
        this.userName = System.getenv("SAUCE_USER_NAME");
        this.accessKey = System.getenv("SAUCE_API_KEY");
        this.buildNumber = System.getenv("BUILD_NUMBER");
        this.jobName = System.getenv("JOB_NAME");

        /*For Debug Purpose*/
        LOG.info("Debug: browser = " + this.browser);
        LOG.info("Debug: version = " + this.version);
        LOG.info("Debug: platform = " + this.platform);
        LOG.info("Debug: userName = " + this.userName);
        LOG.info("Debug: accessKey = " + this.accessKey);
        LOG.info("Debug: executedFrom = " + this.executedFrom);
        LOG.info("Debug: BUILD_NUMBER = " + this.buildNumber);
        LOG.info("Debug: jobName = " + this.jobName);
    }
	

	
   
}
