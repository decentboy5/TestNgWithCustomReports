package test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;



public class Sample {
	public static void main(String[] args) throws Throwable {
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\E002606\\Downloads\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		//Reporters.reportCreater();
		driver.get("https:\\www.google.com");
	}

}
