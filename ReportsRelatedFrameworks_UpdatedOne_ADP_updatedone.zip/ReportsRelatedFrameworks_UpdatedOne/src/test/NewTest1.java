package test;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import accelerators.ActionEngine;
import accelerators.TestEngineWeb;
import report.CReporter;

public class NewTest1 extends ActionEngine{
	
  @Test
  public void ABCDONE() throws Throwable {
	
	  launch();
	  System.out.println("Hello");
	  type(By.name("q"),"Three", "2nd time Search Box111111111");
	
	  
  }
}
