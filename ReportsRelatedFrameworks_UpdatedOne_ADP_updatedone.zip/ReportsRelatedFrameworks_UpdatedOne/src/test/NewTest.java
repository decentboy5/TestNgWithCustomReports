package test;

import java.lang.reflect.Method;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import accelerators.ActionEngine;
import junit.framework.Assert;

public class NewTest extends ActionEngine{
  
	
@Test
  public void FirstScenario() throws Throwable {
	
	System.out.println("  ");
	  launch();
	  Actions ac=new Actions(Driver);
	 String invalidLicenseFileTypeMessag;
	  WebElement ele=Driver.findElement(By.xpath("//input[@id='username']"));
	  //ele.sendKeys("Hellooo");
	 
	  ac.moveToElement(ele).perform();
	  Driver.findElement(By.xpath("//*[contains[(.,'Please')]"));
	  ac.moveToElement(ele).build().perform();
	  
	  JavascriptExecutor js = (JavascriptExecutor) Driver;
	  js.executeScript("arguments[0].onmouseover()", ele);
	 /* try 
	  {
	      String mouseOverScript = "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('mouseover',true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject) { arguments[0].fireEvent('onmouseover');}";
	      ((JavascriptExecutor) Driver).executeScript(mouseOverScript,ele);
	      Thread.sleep(1000);
	      invalidLicenseFileTypeMessag = (String)((JavascriptExecutor)Driver).executeScript("return arguments[0].innerHTML;",ele);


	 } catch (Exception e) {
	     

	 }*/
	  System.out.println("" );
	  Driver.quit();
  }

  
}
