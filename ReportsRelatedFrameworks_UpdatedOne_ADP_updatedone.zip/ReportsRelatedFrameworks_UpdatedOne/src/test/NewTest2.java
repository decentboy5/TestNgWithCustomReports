package test;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import accelerators.ActionEngine;

public class NewTest2 extends ActionEngine{
	
  @Test(priority=1)
  public void ABCD() throws Throwable {
	  launch();
	  System.out.println("Hello");
	  type(By.name("q1"),"Three", "2nd time Search Box111111111");
	
	  
  }
  
  @Test(priority=2)
  public void ABCCD() throws Throwable {
	  launch();
	  System.out.println("Hello");
	  type(By.name("q1"),"Three", "2nd time Search Box111111111");
	
	  
  }
}
